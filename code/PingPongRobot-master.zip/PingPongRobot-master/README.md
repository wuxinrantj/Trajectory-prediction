# PingPongRobotVision

This repository contains.
PS3Eye vision with trajectory planning for Ping Pong Robot Controls.


The ball detection code is based off of Emgu.CV and camera capture is to be used with PS3EYE, modification have to be made to enable sending with other cameras.

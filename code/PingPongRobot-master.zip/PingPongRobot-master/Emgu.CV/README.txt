Version 2.9.0.1922
==================================================================

For online documentation please visit
http://www.emgu.com/wiki/files/2.9.0.0/Index.html

For tutorials and helps please visit the Emgu CV wiki 
http://www.emgu.com/wiki/

For questions and discussions please visit the Emgu CV forum
http://www.emgu.com/forum/

To report a bug, please visit
http://www.emgu.com/bugs/

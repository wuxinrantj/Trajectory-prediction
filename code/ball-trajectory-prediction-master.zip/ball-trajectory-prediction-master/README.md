# Ball-Trajectory-Prediction
Opencv project to predict the trajectory of a ball using interpolation.
